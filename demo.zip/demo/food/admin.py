from django.contrib import admin
from django.db import models
from.models import Post, Post1, Post2, Post3, Post4, Post5, Post6, Post7, Post8, Post9, Post10, Post11, Post12, Post13, Post14, Post15, Post16, Post17, Post18, Post19


admin.site.register(Post)
admin.site.register(Post1)
admin.site.register(Post2)
admin.site.register(Post3)
admin.site.register(Post4)
admin.site.register(Post5)
admin.site.register(Post6)
admin.site.register(Post7)
admin.site.register(Post8)
admin.site.register(Post9)
admin.site.register(Post10)
admin.site.register(Post11)
admin.site.register(Post12)
admin.site.register(Post13)
admin.site.register(Post14)
admin.site.register(Post15)
admin.site.register(Post16)
admin.site.register(Post17)
admin.site.register(Post18)
admin.site.register(Post19)


